import os
from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Load environment variables from .env file if available
load_dotenv(os.path.join(BASE_DIR, '.env'))

# Serverless platforms (Vercel, AWS Lambda) mount the app read-only; only /tmp is writable.
IS_SERVERLESS = bool(os.environ.get('VERCEL') or os.environ.get('AWS_LAMBDA_FUNCTION_NAME'))
WRITABLE_DIR = '/tmp/saisha' if IS_SERVERLESS else BASE_DIR
BUNDLED_SQLITE_PATH = os.path.join(BASE_DIR, 'database', 'saisha_logistics.db')

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'saisha-logistics-super-secret-key-2026')
    
    # Database Configuration: Supabase (PostgreSQL) or fallback to local SQLite
    _db_url = os.environ.get('DATABASE_URL')
    if _db_url:
        # Standardize 'postgres://' or plain 'postgresql://' to explicit 'postgresql+psycopg2://'
        if _db_url.startswith('postgres://'):
            _db_url = _db_url.replace('postgres://', 'postgresql+psycopg2://', 1)
        elif _db_url.startswith('postgresql://'):
            _db_url = _db_url.replace('postgresql://', 'postgresql+psycopg2://', 1)
        SQLALCHEMY_DATABASE_URI = _db_url
    else:
        # Local SQLite fallback (ephemeral copy under /tmp when serverless)
        SQLITE_PATH = os.path.join(WRITABLE_DIR, 'database', 'saisha_logistics.db')
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{SQLITE_PATH}"
        
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Engine connection resiliency (automatic reconnect on idle timeouts)
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
    }
    
    # Directories
    GENERATED_INVOICES_DIR = os.path.join(WRITABLE_DIR, 'generated_invoices')
    EXPORTS_DIR = os.path.join(WRITABLE_DIR, 'exports')
    STATIC_DIR = os.path.join(BASE_DIR, 'static')
    
    # Company Brand Details
    COMPANY_NAME = "SAISHA LOGISTICS"
    COMPANY_TAGLINE = "FLEET OWNERS & TRANSPORT CONTRACTORS"
    COMPANY_ADDRESS = "LIG - II / G - 13 Sector 2-E, Kalamboli, Navi Mumbai - 410218."
    COMPANY_PHONES = "9529923242 / 9865646156"
    COMPANY_EMAIL = "saishalogistics2026@gmail.com"
    COMPANY_PAN = "BYTPCS273P"
    
    # Banking details
    BANK_NAME = "HDFC BANK"
    BANK_BRANCH = "KALAMBOLI"
    BANK_ACCOUNT_NO = "50200110750392"
    BANK_IFSC = "HDFC0002822"
