"""
Migration: Add user_id column to clients, invoices, and payments in Supabase PostgreSQL and local SQLite.
Sets default user_id = 1 (admin) for all existing records so existing data belongs to admin.
"""
import os
import sys
import psycopg2
import sqlite3
from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(BASE_DIR, '.env'))

db_url = os.environ.get('DATABASE_URL')

def migrate_postgres(url):
    print("Migrating Supabase PostgreSQL...")
    conn = psycopg2.connect(url)
    cur = conn.cursor()

    # 1. Add user_id to clients
    cur.execute("""
        ALTER TABLE clients 
        ADD COLUMN IF NOT EXISTS user_id INTEGER REFERENCES users(id) DEFAULT 1;
    """)
    cur.execute("UPDATE clients SET user_id = 1 WHERE user_id IS NULL;")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_clients_user_id ON clients(user_id);")
    print("  + clients.user_id added & indexed.")

    # 2. Add user_id to invoices
    cur.execute("""
        ALTER TABLE invoices 
        ADD COLUMN IF NOT EXISTS user_id INTEGER REFERENCES users(id) DEFAULT 1;
    """)
    cur.execute("UPDATE invoices SET user_id = 1 WHERE user_id IS NULL;")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_invoices_user_id ON invoices(user_id);")
    
    # Drop global invoice_no unique constraint and create composite per-user unique index
    cur.execute("""
        DO $$
        BEGIN
            IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'invoices_invoice_no_key') THEN
                ALTER TABLE invoices DROP CONSTRAINT invoices_invoice_no_key;
            END IF;
        END $$;
    """)
    cur.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS uq_user_invoice_no ON invoices (user_id, invoice_no);
    """)
    print("  + invoices.user_id added & composite unique index (user_id, invoice_no) created.")

    # 3. Add user_id to payments
    cur.execute("""
        ALTER TABLE payments 
        ADD COLUMN IF NOT EXISTS user_id INTEGER REFERENCES users(id) DEFAULT 1;
    """)
    cur.execute("""
        UPDATE payments p
        SET user_id = i.user_id
        FROM invoices i
        WHERE p.invoice_id = i.id AND p.user_id IS NULL;
    """)
    cur.execute("UPDATE payments SET user_id = 1 WHERE user_id IS NULL;")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments(user_id);")
    print("  + payments.user_id added & indexed.")

    conn.commit()
    conn.close()
    print("[SUCCESS] Supabase PostgreSQL migration completed!")

def migrate_sqlite():
    sqlite_path = os.path.join(BASE_DIR, 'database', 'saisha_logistics.db')
    if not os.path.exists(sqlite_path):
        return
    print("Migrating local SQLite...")
    conn = sqlite3.connect(sqlite_path)
    cur = conn.cursor()

    for table in ['clients', 'invoices', 'payments']:
        cur.execute(f"PRAGMA table_info({table})")
        cols = [c[1] for c in cur.fetchall()]
        if 'user_id' not in cols:
            cur.execute(f"ALTER TABLE {table} ADD COLUMN user_id INTEGER DEFAULT 1 REFERENCES users(id)")
            print(f"  + Added user_id to SQLite table {table}")

    conn.commit()
    conn.close()
    print("[SUCCESS] Local SQLite migration completed!")

if __name__ == '__main__':
    if db_url and 'sqlite' not in db_url.lower():
        migrate_postgres(db_url)
    migrate_sqlite()
