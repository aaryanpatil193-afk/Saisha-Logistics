import os
import sys
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
import unittest
from datetime import date
from app import create_app, seed_database
from models import db, User, Client, Invoice, InvoiceItem, InvoiceStop, Payment
from services.invoice_service import get_next_invoice_number
from services.pdf_service import generate_invoice_pdf
from services.excel_service import generate_invoices_excel
from services.amount_to_words import number_to_words_inr

class SaishaLogisticsTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['WTF_CSRF_ENABLED'] = False
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()
        seed_database(self.app)

    def tearDown(self):
        self.app_context.pop()

    @classmethod
    def tearDownClass(cls):
        # Clean up database at the end of all tests so no test data remains
        app = create_app()
        with app.app_context():
            Payment.query.delete()
            InvoiceItem.query.delete()
            InvoiceStop.query.delete()
            Invoice.query.delete()
            Client.query.delete()
            db.session.commit()
            print("Database cleaned to pristine state after test execution.")

    def test_01_admin_user_and_auth(self):
        print("\n--- Test 1: Admin User Authentication ---")
        admin = User.query.filter_by(username='admin').first()
        self.assertIsNotNone(admin)
        self.assertTrue(admin.check_password('admin123'))
        
        # Test Login POST
        res = self.client.post('/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Dashboard', res.data)
        
        # Logout
        self.client.get('/logout')

        # Test Invalid Login
        res_fail = self.client.post('/login', data={'username': 'admin', 'password': 'wrongpassword'}, follow_redirects=True)
        self.assertIn(b'Invalid username or password', res_fail.data)
        print("Admin authentication test passed!")

    def test_02_dashboard_pristine_zero_stats(self):
        print("\n--- Test 2: Dashboard Clean Zero Baseline ---")
        with self.client.session_transaction() as sess:
            sess['user_id'] = 1
            sess['username'] = 'admin'
            sess['full_name'] = 'Administrator'
            
        res = self.client.get('/api/dashboard/stats')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        print(f"Stats returned: {data}")
        self.assertEqual(data['total_clients'], 0)
        self.assertEqual(data['total_invoices'], 0)
        self.assertEqual(data['paid_amount'], 0.0)
        self.assertEqual(data['pending_amount'], 0.0)
        print("Dashboard pristine zero statistics verified!")

    def test_03_client_master_crud(self):
        print("\n--- Test 3: Client Master CRUD & Validation ---")
        with self.client.session_transaction() as sess:
            sess['user_id'] = 1
            sess['username'] = 'admin'

        # Add unique client
        res = self.client.post('/clients/add', data={
            'name': 'Premier Logistics India Ltd',
            'address': 'JNPT Nhava Sheva, Navi Mumbai',
            'mobile': '9876543210',
            'email': 'premier@logistics.in',
            'gst_number': '27ABCDE9999F1Z9',
            'pan_number': 'ABCDE9999F'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        
        client = Client.query.filter_by(name='Premier Logistics India Ltd').first()
        self.assertIsNotNone(client)
        print(f"Created client: {client.name}, ID={client.id}")
        
        # Test duplicate prevention
        res_dup = self.client.post('/clients/add', data={
            'name': 'Premier Logistics India Ltd',
            'address': 'JNPT',
            'mobile': '9876543210',
            'email': 'premier@logistics.in',
            'gst_number': '27ABCDE9999F1Z9',
            'pan_number': 'ABCDE9999F'
        }, follow_redirects=True)
        self.assertIn(b'already exists', res_dup.data)
        print("Client duplicate prevention verified!")

    def test_04_create_invoice_and_calculations(self):
        print("\n--- Test 4: Create Invoice & Calculation Engine ---")
        with self.client.session_transaction() as sess:
            sess['user_id'] = 1
            sess['username'] = 'admin'

        client = Client.query.first()
        next_no = get_next_invoice_number()
        print(f"Next generated invoice number: {next_no}")
        self.assertTrue(next_no.startswith('SL/001/'))
        
        # Create test invoice:
        # Rate: 60,000, Advance: 20,000
        # Container Loading: 2,000, Weight Charges: 500, Parking: 1,000, Detention: 3,000
        # Total Charges = 60000 + 2000 + 500 + 1000 + 3000 = 66,500
        # Gross Total = 66500 - 20000 = 46,500
        res = self.client.post('/invoices/create', data={
            'invoice_no': next_no,
            'client_id': client.id,
            'from_location': 'JNPT Yard',
            'to_location': 'Chakan MIDC Pune',
            'vehicle_no': 'MH43BP9999',
            'container_no': 'TGHU9876543',
            'vehicle_type': '1*40 Export',
            'department': 'Sea Export',
            'weight': '26 MT',
            'bill_date': date.today().strftime('%Y-%m-%d'),
            'movement_date': date.today().strftime('%Y-%m-%d'),
            'rate': '60000',
            'advance': '20000',
            'container_loading_charges': '2000',
            'weight_charges': '500',
            'parking_charges': '1000',
            'detention_charges': '3000',
            'action': 'save_invoice'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        inv = Invoice.query.filter_by(invoice_no=next_no).first()
        self.assertIsNotNone(inv)
        self.assertEqual(inv.total_charges, 66500.0)
        self.assertEqual(inv.gross_total, 46500.0)
        self.assertEqual(inv.pending_amount, 46500.0)
        self.assertEqual(inv.payment_status, 'Pending')
        print(f"Invoice {inv.invoice_no} created and verified: Total={inv.total_charges}, Gross={inv.gross_total}")

    def test_05_pdf_and_excel_generation(self):
        print("\n--- Test 5: ReportLab PDF and openpyxl Excel Generation ---")
        inv = Invoice.query.first()
        self.assertIsNotNone(inv)
        
        # Test PDF generation
        pdf_buf = generate_invoice_pdf(inv)
        pdf_bytes = pdf_buf.read()
        self.assertGreater(len(pdf_bytes), 2000)
        self.assertTrue(pdf_bytes.startswith(b'%PDF-'))
        print(f"Generated A4 PDF size: {len(pdf_bytes)} bytes. Valid PDF header verified!")
        
        # Test Excel generation
        invoices = Invoice.query.all()
        excel_stream = generate_invoices_excel(invoices)
        excel_bytes = excel_stream.read()
        self.assertGreater(len(excel_bytes), 3000)
        self.assertTrue(excel_bytes.startswith(b'PK'))
        print(f"Generated Excel report size: {len(excel_bytes)} bytes. Valid XLSX header verified!")

    def test_06_payment_recording_and_status_transition(self):
        print("\n--- Test 6: Payment Recording & Status Transitions ---")
        with self.client.session_transaction() as sess:
            sess['user_id'] = 1
            sess['username'] = 'admin'

        inv = Invoice.query.filter_by(payment_status='Pending').first()
        self.assertIsNotNone(inv)
        initial_pending = inv.pending_amount
        pay_part = round(initial_pending / 2, 2)

        # 1. Partial Payment
        res1 = self.client.post('/payments/add', data={
            'invoice_id': inv.id,
            'amount': str(pay_part),
            'payment_date': date.today().strftime('%Y-%m-%d'),
            'payment_mode': 'Bank Transfer',
            'reference_no': 'NEFT-PART-123'
        }, follow_redirects=True)
        self.assertEqual(res1.status_code, 200)
        
        db.session.refresh(inv)
        self.assertEqual(inv.payment_status, 'Partially Paid')
        self.assertEqual(inv.paid_amount, pay_part)
        print(f"Invoice {inv.invoice_no} transitioned to Partially Paid: Paid={inv.paid_amount}, Pending={inv.pending_amount}")

        # 2. Settle Remaining Balance
        rem_pending = inv.pending_amount
        res2 = self.client.post('/payments/add', data={
            'invoice_id': inv.id,
            'amount': str(rem_pending),
            'payment_date': date.today().strftime('%Y-%m-%d'),
            'payment_mode': 'UPI',
            'reference_no': 'UPI-FULL-456'
        }, follow_redirects=True)
        self.assertEqual(res2.status_code, 200)

        db.session.refresh(inv)
        self.assertEqual(inv.payment_status, 'Paid')
        self.assertEqual(inv.pending_amount, 0.0)
        print(f"Invoice {inv.invoice_no} transitioned to Paid! Pending balance: {inv.pending_amount}")

if __name__ == '__main__':
    unittest.main(argv=['first-arg-is-ignored'], exit=False)
