import os
import sys
import shutil
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from datetime import date, datetime
from flask import Flask, render_template
from sqlalchemy import inspect, text
from config import Config, BUNDLED_SQLITE_PATH, IS_SERVERLESS
from models import db, User, Client, Invoice, InvoiceItem, Payment, AppSetting
from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.clients import clients_bp
from routes.invoices import invoices_bp
from routes.payments import payments_bp
from routes.export import export_bp

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Ensure writable directories exist (under /tmp on serverless platforms)
    os.makedirs(app.config['GENERATED_INVOICES_DIR'], exist_ok=True)
    os.makedirs(app.config['EXPORTS_DIR'], exist_ok=True)

    sqlite_path = app.config.get('SQLITE_PATH')
    if sqlite_path:
        os.makedirs(os.path.dirname(sqlite_path), exist_ok=True)
        # Seed the serverless /tmp copy from the bundled read-only database
        if not os.path.exists(sqlite_path) and os.path.exists(BUNDLED_SQLITE_PATH) \
                and os.path.abspath(sqlite_path) != os.path.abspath(BUNDLED_SQLITE_PATH):
            shutil.copyfile(BUNDLED_SQLITE_PATH, sqlite_path)
    
    # Initialize SQLAlchemy
    db.init_app(app)
    
    # Register Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(clients_bp)
    app.register_blueprint(invoices_bp)
    app.register_blueprint(payments_bp)
    app.register_blueprint(export_bp)
    
    # Context Processor for company brand details in all templates
    @app.context_processor
    def inject_brand():
        return {
            'company_name': app.config['COMPANY_NAME'],
            'company_tagline': app.config['COMPANY_TAGLINE'],
            'company_address': app.config['COMPANY_ADDRESS'],
            'company_phones': app.config['COMPANY_PHONES'],
            'company_email': app.config['COMPANY_EMAIL'],
            'company_pan': app.config['COMPANY_PAN'],
            'bank_name': app.config['BANK_NAME'],
            'bank_branch': app.config['BANK_BRANCH'],
            'bank_account_no': app.config['BANK_ACCOUNT_NO'],
            'bank_ifsc': app.config['BANK_IFSC'],
        }
        
    # Custom Jinja filters
    @app.template_filter('inr')
    def inr_format(val):
        try:
            return f"₹{float(val):,.2f}"
        except (ValueError, TypeError):
            return "₹0.00"

    @app.template_filter('date_fmt')
    def date_filter(dt, fmt='%d-%m-%Y'):
        if isinstance(dt, (date, datetime)):
            return dt.strftime(fmt)
        return dt or ''

    # Error handlers
    @app.errorhandler(404)
    def not_found(e):
        return render_template('base.html', content_error="404 - Page Not Found"), 404
        
    @app.errorhandler(500)
    def server_error(e):
        return render_template('base.html', content_error="500 - Internal Server Error. Please contact support."), 500

    return app

def seed_database(app):
    with app.app_context():
        db.create_all()

        # Keep existing installations compatible when new invoice fields are introduced.
        invoice_columns = {column['name'] for column in inspect(db.engine).get_columns('invoices')}
        missing_columns = {
            'transport_mode': 'VARCHAR(50)',
            'detention_days': 'VARCHAR(50)',
            'loading_charges': 'FLOAT DEFAULT 0.0',
            'unloading_charges': 'FLOAT DEFAULT 0.0',
            'varahi_charges': 'FLOAT DEFAULT 0.0',
        }
        for column_name, column_type in missing_columns.items():
            if column_name not in invoice_columns:
                try:
                    db.session.execute(text(f'ALTER TABLE invoices ADD COLUMN {column_name} {column_type}'))
                    db.session.commit()
                except Exception as migration_err:
                    db.session.rollback()
                    print(f"Column migration notice ({column_name}): {migration_err}")

        # Ensure detention_days is VARCHAR(50) across databases
        try:
            db.session.execute(text('ALTER TABLE invoices ALTER COLUMN detention_days TYPE VARCHAR(50) USING detention_days::VARCHAR'))
            db.session.commit()
        except Exception:
            db.session.rollback()

        # Initialize the database-backed common password once from the server-only variable.
        # After initialization, only an authenticated admin can change it from Profile.
        if not AppSetting.has_common_password():
            configured_company_password = os.environ.get('COMMON_COMPANY_PASSWORD')
            if configured_company_password:
                AppSetting.set_common_password(configured_company_password)
                db.session.commit()
        
        # Keep existing installations compatible when security question fields are introduced on users.
        user_columns = {column['name'] for column in inspect(db.engine).get_columns('users')}
        missing_user_columns = {
            'sec_first_project': 'VARCHAR(255)',
            'sec_first_job_city': 'VARCHAR(255)',
            'sec_first_software': 'VARCHAR(255)',
            'sec_first_job_role': 'VARCHAR(255)',
            'sec_fav_dish': 'VARCHAR(255)',
            'sec_childhood_name': 'VARCHAR(255)',
            'sec_fav_teacher': 'VARCHAR(255)',
            'sec_birthplace': 'VARCHAR(255)',
        }
        for column_name, column_type in missing_user_columns.items():
            if column_name not in user_columns:
                try:
                    db.session.execute(text(f'ALTER TABLE users ADD COLUMN {column_name} {column_type}'))
                    db.session.commit()
                    print(f"Added column users.{column_name}")
                except Exception as migration_err:
                    db.session.rollback()
                    print(f"Column migration notice (users.{column_name}): {migration_err}")

        # 1. Create Default Admin User
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(
                username='admin',
                full_name='Administrator',
                email='admin@saishalogistics.com',
                role='admin'
            )
            admin.set_password('admin123')
            admin.set_security_answers(
                first_project='snake game',
                first_job_city='mumbai',
                first_software='python',
                first_job_role='admin'
            )
            db.session.add(admin)
            db.session.commit()
            print("Default admin created: admin / admin123")
        else:
            admin.set_security_answers(
                first_project='snake game',
                first_job_city='mumbai',
                first_software='python',
                first_job_role='admin'
            )
            db.session.commit()

app = create_app()

if IS_SERVERLESS:
    try:
        seed_database(app)
    except Exception as exc:
        print(f"Database initialization failed: {exc}", file=sys.stderr)

if __name__ == '__main__':
    seed_database(app)
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=True)
