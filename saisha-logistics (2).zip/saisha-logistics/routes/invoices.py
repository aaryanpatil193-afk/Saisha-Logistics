import os
from datetime import datetime, date
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_file, current_app, session
from sqlalchemy import or_
from sqlalchemy.exc import IntegrityError
from models import db, Client, Invoice, InvoiceItem, InvoiceStop, Payment, User
from routes.auth import login_required
from services.invoice_service import get_next_invoice_number
from services.pdf_service import generate_invoice_pdf
from services.amount_to_words import number_to_words_inr

invoices_bp = Blueprint('invoices', __name__)


def get_current_user_and_role():
    """Helper to retrieve current user and verify admin status."""
    user_id = session.get('user_id')
    user = User.query.get(user_id) if user_id else None
    is_admin = bool(user and user.role == 'admin')
    return user_id, user, is_admin


def parse_date_input(val, default=None):
    """Robustly parse date from ISO (YYYY-MM-DD), Indian/UK (DD/MM/YYYY or D/M/YYYY),
    or hyphenated formats."""
    if not val:
        return default or date.today()
    val = str(val).strip()
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d/%m/%y', '%d-%m-%Y', '%Y/%m/%d'):
        try:
            return datetime.strptime(val, fmt).date()
        except ValueError:
            pass
    parts = val.replace('-', '/').split('/')
    if len(parts) == 3:
        try:
            d, m, y = int(parts[0]), int(parts[1]), int(parts[2])
            if y < 100:
                y += 2000
            return date(y, m, d)
        except Exception:
            pass
    return default or date.today()


def apply_payment_status(invoice, payment_status_input, paid_amount_raw):
    """Dynamically link payments or update status with Payment records,
    then let Invoice.calculate_totals() derive the consistent live pending balance."""
    payment_status_input = (payment_status_input or 'Pending').strip()
    total = invoice.total_bill_amount
    current_paid = invoice.total_paid_amount

    if payment_status_input == 'Paid':
        pending = invoice.pending_balance
        if pending > 0:
            payment = Payment(
                user_id=invoice.user_id,
                invoice_id=invoice.id,
                amount=pending,
                payment_date=date.today(),
                payment_mode='Direct Settlement',
                reference_no='SETTLEMENT-PAID',
                notes='Full settlement payment recorded via status update'
            )
            db.session.add(payment)
            db.session.flush()
    elif payment_status_input == 'Partially Paid':
        try:
            target_amount = float(paid_amount_raw or 0)
        except ValueError:
            target_amount = 0.0
            
        if target_amount > current_paid:
            diff = round(target_amount - current_paid, 2)
            payment = Payment(
                user_id=invoice.user_id,
                invoice_id=invoice.id,
                amount=diff,
                payment_date=date.today(),
                payment_mode='Installment',
                reference_no='PARTIAL-PAYMENT',
                notes='Partial installment payment recorded via status update'
            )
            db.session.add(payment)
            db.session.flush()

    invoice.calculate_totals()

@invoices_bp.route('/invoices/create', methods=['GET', 'POST'])
@login_required
def create():
    user_id, current_user, is_admin = get_current_user_and_role()
    if request.method == 'POST':
        client_id = request.form.get('client_id')
        transport_mode = request.form.get('transport_mode', 'Road').strip()
        from_location = request.form.get('from_location', '').strip()
        to_location = request.form.get('to_location', '').strip()
        vehicle_no = request.form.get('vehicle_no', '').strip()
        container_no = request.form.get('container_no', '').strip()
        vehicle_type = request.form.get('vehicle_type', '').strip()
        weight = request.form.get('weight', '').strip()
        department = request.form.get('department', '').strip()
        stop_locations = [s.strip() for s in request.form.getlist('stop_location[]') if s.strip()]
        
        bill_date_raw = request.form.get('bill_date')
        movement_date_raw = request.form.get('movement_date')
        
        # Parse Dates (Supports YYYY-MM-DD and DD/MM/YYYY)
        bill_date = parse_date_input(bill_date_raw, date.today())
        movement_date = parse_date_input(movement_date_raw, bill_date)

        # Charges Parse & Validate
        try:
            rate = float(request.form.get('rate') or 0.0)
            advance = float(request.form.get('advance') or 0.0)
            loading_charges = float(request.form.get('loading_charges') or request.form.get('container_loading_charges') or 0.0)
            unloading_charges = float(request.form.get('unloading_charges') or 0.0)
            parking_charges = float(request.form.get('parking_charges') or 0.0)
            detention_charges = float(request.form.get('detention_charges') or 0.0)
            detention_days = request.form.get('detention_days', '').strip() or None
            varahi_charges = float(request.form.get('varahi_charges') or 0.0)
            weight_charges = float(request.form.get('weight_charges') or 0.0)
        except ValueError:
            flash('Invalid numeric value entered in charges fields.', 'danger')
            return redirect(url_for('invoices.create'))

        # Validation
        if not client_id:
            flash('Please select a client.', 'danger')
            return redirect(url_for('invoices.create'))
            
        # Verify client: admin can bill for any registered client, operator for own clients
        if is_admin:
            client = Client.query.filter_by(id=int(client_id)).first()
        else:
            client = Client.query.filter_by(id=int(client_id), user_id=user_id).first()
            
        if not client:
            flash('Selected client does not exist or belongs to another profile.', 'danger')
            return redirect(url_for('invoices.create'))
            
        if not from_location or not to_location:
            flash('From and To locations are required.', 'danger')
            return redirect(url_for('invoices.create'))
            
        if not vehicle_no:
            flash('Vehicle Number is required.', 'danger')
            return redirect(url_for('invoices.create'))
            
        # Get next sequential invoice number or use provided if available and unique
        invoice_no = request.form.get('invoice_no', '').strip()
        if not invoice_no or Invoice.query.filter_by(invoice_no=invoice_no).first():
            invoice_no = get_next_invoice_number(bill_date)
            
        while Invoice.query.filter_by(invoice_no=invoice_no).first():
            invoice_no = get_next_invoice_number(bill_date)
            
        detention_description = request.form.get('detention_description', '').strip()

        invoice = Invoice(
            user_id=user_id,
            invoice_no=invoice_no,
            client_id=int(client_id),
            transport_mode=transport_mode or 'Road',
            bill_date=bill_date,
            movement_date=movement_date,
            from_location=from_location,
            to_location=to_location,
            vehicle_no=vehicle_no,
            container_no=container_no,
            vehicle_type=vehicle_type,
            department=department,
            weight=weight,
            rate=rate,
            advance=advance,
            loading_charges=loading_charges,
            container_loading_charges=loading_charges,
            unloading_charges=unloading_charges,
            parking_charges=parking_charges,
            detention_charges=detention_charges,
            detention_days=detention_days,
            detention_description=detention_description,
            varahi_charges=varahi_charges,
            weight_charges=weight_charges,
            paid_amount=0.0
        )
        
        # Calculate totals on backend (Single Source of Truth)
        invoice.calculate_totals()
        
        # Apply user-selected initial payment status (optional, defaults to Pending)
        apply_payment_status(invoice, request.form.get('payment_status', 'Pending'), request.form.get('paid_amount', ''))
        
        try:
            db.session.add(invoice)
            db.session.flush() # get invoice.id
            
            # Add intermediate route stops, in the order entered
            for order, stop_location in enumerate(stop_locations):
                db.session.add(InvoiceStop(invoice_id=invoice.id, stop_order=order, location=stop_location))
            
            # Add primary invoice line item
            route_summary = ' -> '.join([from_location] + stop_locations + [to_location])
            particulars_summary = f"Route: {route_summary} | Type: {vehicle_type} | Dept: {department} | Wt: {weight} | Veh: {vehicle_no} | Cont: {container_no}"
            item = InvoiceItem(
                invoice_id=invoice.id,
                item_date=movement_date,
                particulars=particulars_summary,
                quantity="1",
                rate=rate,
                advance=advance,
                amount=invoice.gross_total
            )
            db.session.add(item)
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            # If a collision occurred on invoice_no, assign the next globally unique invoice number and commit
            invoice_no = get_next_invoice_number(bill_date)
            invoice.invoice_no = invoice_no
            db.session.add(invoice)
            db.session.flush()
            for order, stop_location in enumerate(stop_locations):
                db.session.add(InvoiceStop(invoice_id=invoice.id, stop_order=order, location=stop_location))
            item = InvoiceItem(
                invoice_id=invoice.id,
                item_date=movement_date,
                particulars=particulars_summary,
                quantity="1",
                rate=rate,
                advance=advance,
                amount=invoice.gross_total
            )
            db.session.add(item)
            db.session.commit()
        
        flash(f'Invoice {invoice.invoice_no} created successfully! Total: ₹{invoice.gross_total:,.2f}', 'success')
        
        # Check if user requested direct PDF generation
        if request.form.get('action') == 'generate_pdf':
            return redirect(url_for('invoices.download_pdf', id=invoice.id))
            
        return redirect(url_for('invoices.preview', id=invoice.id))

    # GET request
    if is_admin:
        clients = Client.query.order_by(Client.name.asc()).all()
    else:
        clients = Client.query.filter_by(user_id=user_id).order_by(Client.name.asc()).all()

    next_invoice_no = get_next_invoice_number()
    today_str = date.today().strftime('%Y-%m-%d')
    today_dmy = date.today().strftime('%d/%m/%Y')
    return render_template(
        'create_invoice.html',
        clients=clients,
        next_invoice_no=next_invoice_no,
        today_str=today_str,
        today_dmy=today_dmy
    )

@invoices_bp.route('/invoices/<int:id>/preview')
@login_required
def preview(id):
    user_id, current_user, is_admin = get_current_user_and_role()
    if is_admin:
        invoice = Invoice.query.filter_by(id=id).first_or_404()
    else:
        invoice = Invoice.query.filter_by(id=id, user_id=user_id).first_or_404()
    amount_words = number_to_words_inr(invoice.gross_total)
    payment_breakdown = invoice.get_payment_breakdown()
    return render_template(
        'invoice_preview.html',
        invoice=invoice,
        amount_words=amount_words,
        is_admin=is_admin,
        payment_breakdown=payment_breakdown,
        today_str=date.today().strftime('%Y-%m-%d')
    )

@invoices_bp.route('/invoices/<int:id>/pdf')
@login_required
def download_pdf(id):
    user_id, current_user, is_admin = get_current_user_and_role()
    if is_admin:
        invoice = Invoice.query.filter_by(id=id).first_or_404()
    else:
        invoice = Invoice.query.filter_by(id=id, user_id=user_id).first_or_404()
    
    # Generate clean PDF in memory
    pdf_buffer = generate_invoice_pdf(invoice)
    
    # Standardize filename format: SAISHA_INVOICE_SL_001_26-27.pdf
    safe_no = invoice.invoice_no.replace('/', '_').replace('-', '_')
    filename = f"SAISHA_INVOICE_{safe_no}.pdf"
    
    return send_file(
        pdf_buffer,
        mimetype='application/pdf',
        as_attachment=True,
        download_name=filename
    )

@invoices_bp.route('/invoices/history')
@login_required
def history():
    user_id, current_user, is_admin = get_current_user_and_role()
    # Filter and Search parameters
    search = request.args.get('search', '').strip()
    filter_user_id = request.args.get('user_id', '').strip()
    client_id = request.args.get('client_id')
    status = request.args.get('status', '').strip()
    from_date = request.args.get('from_date', '').strip()
    to_date = request.args.get('to_date', '').strip()
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)

    if is_admin:
        query = Invoice.query.options(db.joinedload(Invoice.user), db.joinedload(Invoice.client))
        if filter_user_id and filter_user_id.isdigit():
            query = query.filter(Invoice.user_id == int(filter_user_id))
        all_users = User.query.order_by(User.role.asc(), User.full_name.asc()).all()
        clients = Client.query.order_by(Client.name.asc()).all()
    else:
        query = Invoice.query.filter_by(user_id=user_id).options(db.joinedload(Invoice.client))
        all_users = []
        clients = Client.query.filter_by(user_id=user_id).order_by(Client.name.asc()).all()

    if search:
        search_filter = or_(
            Invoice.invoice_no.ilike(f'%{search}%'),
            Invoice.vehicle_no.ilike(f'%{search}%'),
            Invoice.container_no.ilike(f'%{search}%'),
            Invoice.from_location.ilike(f'%{search}%'),
            Invoice.to_location.ilike(f'%{search}%')
        )
        if is_admin:
            client_matches = Client.query.filter(Client.name.ilike(f'%{search}%')).all()
            user_matches = User.query.filter(or_(
                User.full_name.ilike(f'%{search}%'),
                User.username.ilike(f'%{search}%'),
                User.email.ilike(f'%{search}%')
            )).all()
            if user_matches:
                search_filter = or_(search_filter, Invoice.user_id.in_([u.id for u in user_matches]))
        else:
            client_matches = Client.query.filter(Client.user_id == user_id, Client.name.ilike(f'%{search}%')).all()

        if client_matches:
            c_ids = [c.id for c in client_matches]
            search_filter = or_(search_filter, Invoice.client_id.in_(c_ids))

        query = query.filter(search_filter)

    if client_id and client_id.isdigit():
        query = query.filter(Invoice.client_id == int(client_id))

    if status and status != 'All':
        query = query.filter(Invoice.payment_status == status)

    if from_date:
        fd = parse_date_input(from_date, default=None)
        if fd:
            query = query.filter(Invoice.bill_date >= fd)

    if to_date:
        td = parse_date_input(to_date, default=None)
        if td:
            query = query.filter(Invoice.bill_date <= td)

    # Order chronologically by bill date desc, id desc
    query = query.order_by(Invoice.bill_date.desc(), Invoice.id.desc())
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    invoices = pagination.items
    
    return render_template(
        'invoice_history.html',
        invoices=invoices,
        pagination=pagination,
        clients=clients,
        all_users=all_users,
        is_admin=is_admin,
        search=search,
        filter_user_id=filter_user_id,
        client_id=client_id,
        status=status,
        from_date=from_date,
        to_date=to_date,
        per_page=per_page
    )

@invoices_bp.route('/invoices/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    user_id, current_user, is_admin = get_current_user_and_role()
    if is_admin:
        invoice = Invoice.query.filter_by(id=id).first_or_404()
    else:
        invoice = Invoice.query.filter_by(id=id, user_id=user_id).first_or_404()
    
    if request.method == 'POST':
        client_id = request.form.get('client_id')
        transport_mode = request.form.get('transport_mode', 'Road').strip()
        from_location = request.form.get('from_location', '').strip()
        to_location = request.form.get('to_location', '').strip()
        vehicle_no = request.form.get('vehicle_no', '').strip()
        container_no = request.form.get('container_no', '').strip()
        vehicle_type = request.form.get('vehicle_type', '').strip()
        department = request.form.get('department', '').strip()
        weight = request.form.get('weight', '').strip()
        stop_locations = [s.strip() for s in request.form.getlist('stop_location[]') if s.strip()]
        
        bill_date_raw = request.form.get('bill_date')
        movement_date_raw = request.form.get('movement_date')
        
        if bill_date_raw:
            invoice.bill_date = parse_date_input(bill_date_raw, invoice.bill_date)
        if movement_date_raw:
            invoice.movement_date = parse_date_input(movement_date_raw, invoice.movement_date)
            
        try:
            invoice.rate = float(request.form.get('rate') or 0.0)
            invoice.advance = float(request.form.get('advance') or 0.0)
            invoice.loading_charges = float(request.form.get('loading_charges') or request.form.get('container_loading_charges') or 0.0)
            invoice.container_loading_charges = invoice.loading_charges
            invoice.unloading_charges = float(request.form.get('unloading_charges') or 0.0)
            invoice.parking_charges = float(request.form.get('parking_charges') or 0.0)
            invoice.detention_charges = float(request.form.get('detention_charges') or 0.0)
            invoice.detention_days = request.form.get('detention_days', '').strip() or None
            invoice.varahi_charges = float(request.form.get('varahi_charges') or 0.0)
            invoice.weight_charges = float(request.form.get('weight_charges') or 0.0)
        except ValueError:
            flash('Invalid numeric charges entered.', 'danger')
            return redirect(url_for('invoices.edit', id=id))

        if client_id:
            if is_admin:
                client = Client.query.filter_by(id=int(client_id)).first()
            else:
                client = Client.query.filter_by(id=int(client_id), user_id=user_id).first()
            if client:
                invoice.client_id = int(client_id)

        invoice.transport_mode = transport_mode or 'Road'
        invoice.from_location = from_location
        invoice.to_location = to_location
        invoice.vehicle_no = vehicle_no
        invoice.container_no = container_no
        invoice.vehicle_type = vehicle_type
        invoice.department = department
        invoice.weight = weight
        invoice.detention_description = request.form.get('detention_description', '').strip()
        
        # Replace intermediate route stops with the submitted list, preserving order
        invoice.stops = [
            InvoiceStop(invoice_id=invoice.id, stop_order=order, location=loc)
            for order, loc in enumerate(stop_locations)
        ]
        
        # Recalculate totals
        invoice.calculate_totals()
        
        # Apply user-selected payment status (optional, keeps current status if not provided)
        apply_payment_status(invoice, request.form.get('payment_status', invoice.payment_status), request.form.get('paid_amount', ''))
        
        db.session.commit()
        flash(f'Invoice {invoice.invoice_no} updated successfully!', 'success')
        return redirect(url_for('invoices.preview', id=invoice.id))
        
    if is_admin:
        clients = Client.query.order_by(Client.name.asc()).all()
    else:
        clients = Client.query.filter_by(user_id=user_id).order_by(Client.name.asc()).all()
    today_dmy = date.today().strftime('%d/%m/%Y')
    return render_template('create_invoice.html', invoice=invoice, clients=clients, is_edit=True, today_dmy=today_dmy)

@invoices_bp.route('/invoices/<int:id>/update-status', methods=['POST'])
@login_required
def update_status(id):
    user_id, current_user, is_admin = get_current_user_and_role()
    if is_admin:
        invoice = Invoice.query.filter_by(id=id).first_or_404()
    else:
        invoice = Invoice.query.filter_by(id=id, user_id=user_id).first_or_404()

    apply_payment_status(invoice, request.form.get('payment_status', 'Pending'), request.form.get('paid_amount', ''))

    db.session.commit()
    flash(f'Payment status for invoice {invoice.invoice_no} updated to "{invoice.payment_status}".', 'success')

    next_url = request.form.get('next') or url_for('invoices.history')
    return redirect(next_url)


@invoices_bp.route('/invoices/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    user_id, current_user, is_admin = get_current_user_and_role()
    if is_admin:
        invoice = Invoice.query.filter_by(id=id).first_or_404()
    else:
        invoice = Invoice.query.filter_by(id=id, user_id=user_id).first_or_404()
    inv_no = invoice.invoice_no
    db.session.delete(invoice)
    db.session.commit()
    flash(f'Invoice {inv_no} deleted successfully.', 'info')
    return redirect(url_for('invoices.history'))

@invoices_bp.route('/api/invoices/<int:id>')
@login_required
def get_invoice_json(id):
    user_id, current_user, is_admin = get_current_user_and_role()
    if is_admin:
        invoice = Invoice.query.filter_by(id=id).first_or_404()
    else:
        invoice = Invoice.query.filter_by(id=id, user_id=user_id).first_or_404()
    return jsonify(invoice.to_dict())

@invoices_bp.route('/api/invoices/next-number')
@login_required
def get_next_number_api():
    return jsonify({'next_number': get_next_invoice_number()})
