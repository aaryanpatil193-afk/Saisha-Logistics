from flask import Blueprint, send_file, request, session
from models import Invoice, User
from routes.auth import login_required
from services.excel_service import generate_invoices_excel

export_bp = Blueprint('export', __name__)

@export_bp.route('/export/excel')
@login_required
def export_excel():
    user_id = session.get('user_id')
    current_user = User.query.get(user_id)
    is_admin = bool(current_user and current_user.role == 'admin')
    
    # Allow filtering exports just like invoice history
    status = request.args.get('status', '').strip()
    client_id = request.args.get('client_id')
    filter_user_id = request.args.get('user_id', '').strip()
    
    if is_admin:
        query = Invoice.query
        if filter_user_id and filter_user_id.isdigit():
            query = query.filter(Invoice.user_id == int(filter_user_id))
    else:
        query = Invoice.query.filter_by(user_id=user_id)

    if status and status != 'All':
        query = query.filter(Invoice.payment_status == status)
    if client_id and client_id.isdigit():
        query = query.filter(Invoice.client_id == int(client_id))
        
    invoices = query.order_by(Invoice.bill_date.desc(), Invoice.id.desc()).all()
    
    excel_stream = generate_invoices_excel(invoices)
    
    filename = "SAISHA_INVOICE_REPORT.xlsx"
    
    return send_file(
        excel_stream,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=filename
    )
