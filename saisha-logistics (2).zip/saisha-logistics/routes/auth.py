from functools import wraps
import json
import os
import random
import re
import time
from datetime import datetime, timedelta
from hmac import compare_digest
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify, current_app
from sqlalchemy import func
from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadSignature

COMPANY_PASSWORD_ENV = 'COMMON_COMPANY_PASSWORD'
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$')

SECURITY_QUESTIONS = {
    'first_project': 'What was the first project you worked on?',
    'first_job_city': 'In which city did you complete your first job?',
    'first_software': 'What was the first software you learned to use?',
    'first_job_role': 'What was your first job role?'
}

from models import db, User, AppSetting, PasswordResetOTP
from services.email_service import send_otp_email, send_password_reset_email, is_smtp_configured

auth_bp = Blueprint('auth', __name__)


def generate_reset_token(email):
    """Generate a cryptographically signed, URL-safe password reset token (legacy helper)."""
    secret = current_app.config.get('SECRET_KEY', 'saisha-logistics-super-secret-key-2026')
    s = URLSafeTimedSerializer(secret)
    return s.dumps(email.lower().strip(), salt='password-reset-salt')


def verify_reset_token(token, max_age=3600):
    """Verify a password reset token and return the associated email, or None if expired/tampered."""
    if not token:
        return None
    secret = current_app.config.get('SECRET_KEY', 'saisha-logistics-super-secret-key-2026')
    s = URLSafeTimedSerializer(secret)
    try:
        email = s.loads(token, salt='password-reset-salt', max_age=max_age)
        return email
    except (SignatureExpired, BadSignature):
        return None


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            if request.is_json or request.path.startswith('/api/'):
                return jsonify({'error': 'Unauthorized', 'message': 'Please login to continue.'}), 401
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function


@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        if not email or not EMAIL_REGEX.match(email):
            flash('Please enter a valid registered email address.', 'danger')
            return render_template('forgot_password.html', email=email)

        user = User.query.filter(func.lower(User.email) == email).first()
        if not user:
            flash('No account found with this email address. Please check and try again.', 'danger')
            return render_template('forgot_password.html', email=email)

        # Get available security questions for this user
        available_questions = user.get_available_security_questions()
        if not available_questions:
            # Fallback for accounts created prior to security questions
            user.set_security_answers(
                first_project='snake game',
                first_job_city='mumbai',
                first_software='python',
                first_job_role='admin'
            )
            db.session.commit()
            available_questions = user.get_available_security_questions()

        # Pick a random question from the 4 security questions
        chosen_key, chosen_question = random.choice(available_questions)

        session['reset_email'] = user.email.lower().strip()
        session['sec_question_key'] = chosen_key
        session['sec_question_text'] = chosen_question
        session['sec_question_attempts'] = 0

        return redirect(url_for('auth.verify_security_question'))

    return render_template('forgot_password.html', email=session.get('reset_email', ''))


@auth_bp.route('/verify-security-question', methods=['GET', 'POST'])
def verify_security_question():
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))

    reset_email = session.get('reset_email')
    question_key = session.get('sec_question_key')
    question_text = session.get('sec_question_text')

    if not reset_email or not question_key or not question_text:
        flash('Please enter your email address to initiate password reset.', 'warning')
        return redirect(url_for('auth.forgot_password'))

    user = User.query.filter(func.lower(User.email) == reset_email).first()
    if not user:
        flash('Account not found. Please try again.', 'danger')
        return redirect(url_for('auth.forgot_password'))

    if request.method == 'POST':
        action = request.form.get('action')
        # Allow user to switch question if desired
        if action == 'switch_question':
            available = user.get_available_security_questions()
            other_questions = [q for q in available if q[0] != question_key]
            chosen = random.choice(other_questions) if other_questions else random.choice(available)
            session['sec_question_key'] = chosen[0]
            session['sec_question_text'] = chosen[1]
            return redirect(url_for('auth.verify_security_question'))

        answer = request.form.get('security_answer', '').strip()
        if not answer:
            flash('Please enter your answer.', 'danger')
            return render_template('verify_security_question.html', email=reset_email, question=question_text)

        attempts = session.get('sec_question_attempts', 0)
        if attempts >= 5:
            session.pop('reset_email', None)
            session.pop('sec_question_key', None)
            session.pop('sec_question_text', None)
            session.pop('sec_question_attempts', None)
            flash('Too many incorrect attempts. For security reasons, please start over.', 'danger')
            return redirect(url_for('auth.forgot_password'))

        if not user.check_security_answer(question_key, answer):
            attempts += 1
            session['sec_question_attempts'] = attempts
            remaining = max(0, 5 - attempts)
            if remaining == 0:
                session.pop('reset_email', None)
                session.pop('sec_question_key', None)
                session.pop('sec_question_text', None)
                session.pop('sec_question_attempts', None)
                flash('Too many incorrect attempts. Please start over.', 'danger')
                return redirect(url_for('auth.forgot_password'))
            flash(f'Incorrect answer. Please check and try again. ({remaining} attempt(s) remaining)', 'danger')
            return render_template('verify_security_question.html', email=reset_email, question=question_text)

        # Answer matched! Authorize password reset session (valid for 15 minutes)
        session['reset_authorized_email'] = reset_email
        session['reset_authorized_at'] = time.time()

        # Clear question verification temporary keys
        session.pop('sec_question_key', None)
        session.pop('sec_question_text', None)
        session.pop('sec_question_attempts', None)

        flash('Identity verified successfully! Please enter your new password.', 'success')
        return redirect(url_for('auth.reset_password'))

    return render_template('verify_security_question.html', email=reset_email, question=question_text)


@auth_bp.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))

    auth_email = session.get('reset_authorized_email')
    auth_at = session.get('reset_authorized_at')

    # Security check: User must NOT access /reset-password without verified security question
    if not auth_email or not auth_at:
        flash('Unauthorized access. Please answer your security question to reset your password.', 'danger')
        return redirect(url_for('auth.forgot_password'))

    # Expire reset authorization after 15 minutes (900 seconds)
    if time.time() - auth_at > 900:
        session.pop('reset_authorized_email', None)
        session.pop('reset_authorized_at', None)
        flash('Your password reset authorization has expired. Please verify your security question again.', 'danger')
        return redirect(url_for('auth.forgot_password'))

    user = User.query.filter(func.lower(User.email) == auth_email.lower()).first()
    if not user:
        flash('Account not found for this reset request.', 'danger')
        return redirect(url_for('auth.forgot_password'))

    if request.method == 'POST':
        password = request.form.get('password', '').strip()
        confirm_password = request.form.get('confirm_password', '').strip()

        if len(password) < 6 or len(password) > 128:
            flash('Password must be at least 6 characters long.', 'danger')
            return render_template('reset_password.html', email=auth_email)

        if password != confirm_password:
            flash('Passwords do not match. Please enter matching passwords.', 'danger')
            return render_template('reset_password.html', email=auth_email)

        # Securely update user password
        user.set_password(password)
        db.session.commit()

        # Clear all reset session variables
        session.pop('reset_authorized_email', None)
        session.pop('reset_authorized_at', None)
        session.pop('reset_email', None)

        flash('Password Reset Successful! Your password has been updated. Please log in with your new password.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('reset_password.html', email=auth_email)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))
        
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        company_password = request.form.get('company_password', '')
        
        if not username or not password or not company_password:
            flash('Please provide username, password, and the Common Company Password.', 'danger')
            return render_template('login.html', username=username)

        if not AppSetting.check_common_password(company_password):
            flash('Incorrect Common Company Password. Login denied.', 'danger')
            return render_template('login.html', username=username)
            
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password) and user.is_active:
            session['user_id'] = user.id
            session['username'] = user.username
            session['full_name'] = user.full_name
            session['role'] = user.role
            
            flash(f'Welcome back, {user.full_name}!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page if next_page else url_for('dashboard.index'))
        else:
            flash('Invalid username or password. Please try again.', 'danger')
            return render_template('login.html', username=username)
            
    return render_template('login.html')

@auth_bp.route('/signup', methods=['GET', 'POST'])
@auth_bp.route('/register', methods=['GET', 'POST'])
def signup():
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))
        
    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        company_password = request.form.get('company_password', '')

        # Security questions for password recovery
        sec_first_project = (request.form.get('sec_first_project') or request.form.get('sec_fav_dish') or '').strip()
        sec_first_job_city = (request.form.get('sec_first_job_city') or request.form.get('sec_childhood_name') or '').strip()
        sec_first_software = (request.form.get('sec_first_software') or request.form.get('sec_fav_teacher') or '').strip()
        sec_first_job_role = (request.form.get('sec_first_job_role') or request.form.get('sec_birthplace') or '').strip()

        form_context = {
            'full_name': full_name,
            'username': username,
            'email': email,
            'sec_first_project': sec_first_project,
            'sec_first_job_city': sec_first_job_city,
            'sec_first_software': sec_first_software,
            'sec_first_job_role': sec_first_job_role,
            # Legacy keys for template backward compatibility
            'sec_fav_dish': sec_first_project,
            'sec_childhood_name': sec_first_job_city,
            'sec_fav_teacher': sec_first_software,
            'sec_birthplace': sec_first_job_role
        }
        
        # 1. Required core fields
        if not full_name or not username or not email or not password or not company_password:
            flash('Full Name, Username, Email, Password, and Common Company Password are required.', 'danger')
            return render_template('signup.html', **form_context)

        # 2. Email format validation
        if not EMAIL_REGEX.match(email):
            flash('Please enter a valid email address.', 'danger')
            return render_template('signup.html', **form_context)

        # 3. Security questions validation (all 4 are required)
        if not sec_first_project or not sec_first_job_city or not sec_first_software or not sec_first_job_role:
            flash('Please answer all 4 security questions for password recovery.', 'danger')
            return render_template('signup.html', **form_context)

        # 4. Common Company Password check
        configured_company_password = os.environ.get(COMPANY_PASSWORD_ENV)
        if not configured_company_password:
            flash('Company registration is temporarily unavailable. Please contact an administrator.', 'danger')
            return render_template('signup.html', **form_context)
        if not compare_digest(company_password, configured_company_password):
            flash('The Common Company Password is incorrect.', 'danger')
            return render_template('signup.html', **form_context)
            
        # 5. Username format and length
        if len(username) < 3:
            flash('Username must be at least 3 characters long.', 'danger')
            return render_template('signup.html', **form_context)
            
        if not username.replace('_', '').replace('.', '').isalnum():
            flash('Username can only contain letters, numbers, dots, and underscores.', 'danger')
            return render_template('signup.html', **form_context)
            
        # 6. Password validation
        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'danger')
            return render_template('signup.html', **form_context)
            
        if password != confirm_password:
            flash('Passwords do not match. Please re-enter.', 'danger')
            return render_template('signup.html', **form_context)
            
        # 7. Check existing username
        existing_user = User.query.filter(User.username.ilike(username)).first()
        if existing_user:
            flash(f'Username "{username}" is already taken. Please choose another.', 'warning')
            return render_template('signup.html', **form_context)
            
        # 8. Check existing email
        existing_email = User.query.filter(User.email.ilike(email)).first()
        if existing_email:
            flash('An account with this email address already exists. Please log in or use Forgot Password.', 'warning')
            return render_template('signup.html', **form_context)
                
        # 9. Create and save new user with security answers
        new_user = User(
            username=username,
            full_name=full_name,
            email=email,
            role='operator',
            is_active=True
        )
        new_user.set_password(password)
        new_user.set_security_answers(
            first_project=sec_first_project,
            first_job_city=sec_first_job_city,
            first_software=sec_first_software,
            first_job_role=sec_first_job_role
        )
        db.session.add(new_user)
        db.session.commit()
        
        # 10. Auto-login new user
        session['user_id'] = new_user.id
        session['username'] = new_user.username
        session['full_name'] = new_user.full_name
        session['role'] = new_user.role
        
        flash(f'Welcome to Saisha Logistics, {new_user.full_name}! Your account has been created.', 'success')
        return redirect(url_for('dashboard.index'))
        
    return render_template('signup.html')


@auth_bp.route('/logout')
def logout():
    session.clear()
    flash('You have been successfully logged out.', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    user = User.query.get(session['user_id'])
    if not user:
        session.clear()
        return redirect(url_for('auth.login'))
        
    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        current_password = request.form.get('current_password', '')
        new_password = request.form.get('new_password', '')
        confirm_password = request.form.get('confirm_password', '')
        common_password = request.form.get('common_company_password', '')
        common_password_confirm = request.form.get('common_company_password_confirm', '')

        # Security questions update
        sec_first_project = (request.form.get('sec_first_project') or request.form.get('sec_fav_dish') or '').strip()
        sec_first_job_city = (request.form.get('sec_first_job_city') or request.form.get('sec_childhood_name') or '').strip()
        sec_first_software = (request.form.get('sec_first_software') or request.form.get('sec_fav_teacher') or '').strip()
        sec_first_job_role = (request.form.get('sec_first_job_role') or request.form.get('sec_birthplace') or '').strip()
        
        if full_name:
            user.full_name = full_name
            session['full_name'] = full_name
        if email:
            user.email = email
            
        if new_password:
            if not user.check_password(current_password):
                flash('Current password is incorrect.', 'danger')
                return render_template('profile.html', user=user)
            if new_password != confirm_password:
                flash('New passwords do not match.', 'danger')
                return render_template('profile.html', user=user)
            if len(new_password) < 6:
                flash('New password must be at least 6 characters long.', 'danger')
                return render_template('profile.html', user=user)
            user.set_password(new_password)
            flash('Password updated successfully!', 'success')

        if sec_first_project or sec_first_job_city or sec_first_software or sec_first_job_role:
            user.set_security_answers(
                first_project=sec_first_project,
                first_job_city=sec_first_job_city,
                first_software=sec_first_software,
                first_job_role=sec_first_job_role
            )
            flash('Security questions updated successfully!', 'success')

        if common_password or common_password_confirm:
            if user.role != 'admin':
                flash('Only an administrator can change the Common Company Password.', 'danger')
                return render_template('profile.html', user=user)
            if len(common_password) < 6:
                flash('The Common Company Password must be at least 6 characters long.', 'danger')
                return render_template('profile.html', user=user)
            if common_password != common_password_confirm:
                flash('Common Company Passwords do not match.', 'danger')
                return render_template('profile.html', user=user)
            AppSetting.set_common_password(common_password)
            flash('Common Company Password updated successfully.', 'success')
            
        db.session.commit()
        flash('Profile settings updated successfully!', 'success')
        return redirect(url_for('auth.profile'))
        
    return render_template('profile.html', user=user)
