from flask import Blueprint, render_template, jsonify, session, redirect, url_for, request
from sqlalchemy import func, or_
from models import db, Client, Invoice, Payment, User
from routes.auth import login_required
from routes.invoices import parse_date_input

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/')
def landing():
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))
    return render_template('index.html')

@dashboard_bp.route('/dashboard')
@login_required
def index():
    user_id = session.get('user_id')
    current_user = User.query.get(user_id)
    is_admin = bool(current_user and current_user.role == 'admin')

    # Filter and Search parameters
    search = request.args.get('search', '').strip()
    filter_user_id = request.args.get('user_id', '').strip()
    status = request.args.get('status', '').strip()
    from_date = request.args.get('from_date', '').strip()
    to_date = request.args.get('to_date', '').strip()

    users_breakdown = []
    all_registered_users = []

    if is_admin:
        # System-wide metrics for administrator
        total_clients = db.session.query(func.count(Client.id)).scalar() or 0
        total_invoices = db.session.query(func.count(Invoice.id)).scalar() or 0
        
        pending_invoices_count = db.session.query(func.count(Invoice.id)).filter(
            Invoice.payment_status.in_(['Pending', 'Partially Paid'])
        ).scalar() or 0
        
        paid_invoices_count = db.session.query(func.count(Invoice.id)).filter(
            Invoice.payment_status == 'Paid'
        ).scalar() or 0
        
        pending_amount_total = db.session.query(func.sum(Invoice.pending_amount)).scalar() or 0.0
        paid_amount_total = db.session.query(func.sum(Invoice.paid_amount)).scalar() or 0.0

        # User-wise Invoice Breakdown across all registered users
        all_registered_users = User.query.order_by(User.role.asc(), User.full_name.asc()).all()
        for u in all_registered_users:
            u_count = db.session.query(func.count(Invoice.id)).filter(Invoice.user_id == u.id).scalar() or 0
            u_gross = db.session.query(func.sum(Invoice.gross_total)).filter(Invoice.user_id == u.id).scalar() or 0.0
            u_paid = db.session.query(func.sum(Invoice.paid_amount)).filter(Invoice.user_id == u.id).scalar() or 0.0
            u_pending = db.session.query(func.sum(Invoice.pending_amount)).filter(Invoice.user_id == u.id).scalar() or 0.0
            users_breakdown.append({
                'user': u,
                'invoice_count': u_count,
                'gross_total': u_gross,
                'paid_amount': u_paid,
                'pending_amount': u_pending
            })

        # All invoices query for admin with eager relationship loading
        inv_query = Invoice.query.options(db.joinedload(Invoice.user), db.joinedload(Invoice.client))
        if filter_user_id and filter_user_id.isdigit():
            inv_query = inv_query.filter(Invoice.user_id == int(filter_user_id))

    else:
        # Metrics strictly scoped to current user for privacy
        total_clients = db.session.query(func.count(Client.id)).filter(Client.user_id == user_id).scalar() or 0
        total_invoices = db.session.query(func.count(Invoice.id)).filter(Invoice.user_id == user_id).scalar() or 0
        
        pending_invoices_count = db.session.query(func.count(Invoice.id)).filter(
            Invoice.user_id == user_id,
            Invoice.payment_status.in_(['Pending', 'Partially Paid'])
        ).scalar() or 0
        
        paid_invoices_count = db.session.query(func.count(Invoice.id)).filter(
            Invoice.user_id == user_id,
            Invoice.payment_status == 'Paid'
        ).scalar() or 0
        
        pending_amount_total = db.session.query(func.sum(Invoice.pending_amount)).filter(
            Invoice.user_id == user_id
        ).scalar() or 0.0
        paid_amount_total = db.session.query(func.sum(Invoice.paid_amount)).filter(
            Invoice.user_id == user_id
        ).scalar() or 0.0

        inv_query = Invoice.query.filter(Invoice.user_id == user_id).options(db.joinedload(Invoice.client))

    # Apply search filter
    if search:
        search_filter = or_(
            Invoice.invoice_no.ilike(f'%{search}%'),
            Invoice.vehicle_no.ilike(f'%{search}%'),
            Invoice.container_no.ilike(f'%{search}%'),
            Invoice.from_location.ilike(f'%{search}%'),
            Invoice.to_location.ilike(f'%{search}%')
        )
        if is_admin:
            client_matches = Client.query.filter(Client.name.ilike(f'%{search}%')).all()
            user_matches = User.query.filter(or_(
                User.full_name.ilike(f'%{search}%'),
                User.username.ilike(f'%{search}%'),
                User.email.ilike(f'%{search}%')
            )).all()
            if user_matches:
                search_filter = or_(search_filter, Invoice.user_id.in_([u.id for u in user_matches]))
        else:
            client_matches = Client.query.filter(Client.user_id == user_id, Client.name.ilike(f'%{search}%')).all()

        if client_matches:
            search_filter = or_(search_filter, Invoice.client_id.in_([c.id for c in client_matches]))

        inv_query = inv_query.filter(search_filter)

    # Apply status filter
    if status and status != 'All':
        inv_query = inv_query.filter(Invoice.payment_status == status)

    # Apply date filters
    if from_date:
        fd = parse_date_input(from_date, default=None)
        if fd:
            inv_query = inv_query.filter(Invoice.bill_date >= fd)

    if to_date:
        td = parse_date_input(to_date, default=None)
        if td:
            inv_query = inv_query.filter(Invoice.bill_date <= td)

    # Order chronologically: bill_date descending, then id descending
    invoices = inv_query.order_by(Invoice.bill_date.desc(), Invoice.id.desc()).all()
    
    stats = {
        'total_clients': total_clients,
        'total_invoices': total_invoices,
        'pending_invoices': pending_invoices_count,
        'pending_amount': pending_amount_total,
        'paid_invoices': paid_invoices_count,
        'paid_amount': paid_amount_total,
    }
    
    return render_template(
        'dashboard.html',
        stats=stats,
        invoices=invoices,
        is_admin=is_admin,
        users_breakdown=users_breakdown,
        all_registered_users=all_registered_users,
        search=search,
        filter_user_id=filter_user_id,
        status=status,
        from_date=from_date,
        to_date=to_date
    )

@dashboard_bp.route('/api/dashboard/stats')
@login_required
def get_stats_api():
    user_id = session.get('user_id')
    current_user = User.query.get(user_id)
    is_admin = bool(current_user and current_user.role == 'admin')

    if is_admin:
        total_clients = db.session.query(func.count(Client.id)).scalar() or 0
        total_invoices = db.session.query(func.count(Invoice.id)).scalar() or 0
        pending_invoices = db.session.query(func.count(Invoice.id)).filter(
            Invoice.payment_status.in_(['Pending', 'Partially Paid'])
        ).scalar() or 0
        paid_invoices = db.session.query(func.count(Invoice.id)).filter(
            Invoice.payment_status == 'Paid'
        ).scalar() or 0
        pending_amount = db.session.query(func.sum(Invoice.pending_amount)).scalar() or 0.0
        paid_amount = db.session.query(func.sum(Invoice.paid_amount)).scalar() or 0.0
    else:
        total_clients = db.session.query(func.count(Client.id)).filter(Client.user_id == user_id).scalar() or 0
        total_invoices = db.session.query(func.count(Invoice.id)).filter(Invoice.user_id == user_id).scalar() or 0
        pending_invoices = db.session.query(func.count(Invoice.id)).filter(
            Invoice.user_id == user_id,
            Invoice.payment_status.in_(['Pending', 'Partially Paid'])
        ).scalar() or 0
        paid_invoices = db.session.query(func.count(Invoice.id)).filter(
            Invoice.user_id == user_id,
            Invoice.payment_status == 'Paid'
        ).scalar() or 0
        pending_amount = db.session.query(func.sum(Invoice.pending_amount)).filter(
            Invoice.user_id == user_id
        ).scalar() or 0.0
        paid_amount = db.session.query(func.sum(Invoice.paid_amount)).filter(
            Invoice.user_id == user_id
        ).scalar() or 0.0
    
    return jsonify({
        'total_clients': total_clients,
        'total_invoices': total_invoices,
        'pending_invoices': pending_invoices,
        'pending_amount': pending_amount,
        'paid_invoices': paid_invoices,
        'paid_amount': paid_amount,
        'is_admin': is_admin
    })
