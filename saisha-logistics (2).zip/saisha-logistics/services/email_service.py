import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import logging
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DOTENV_PATH = os.path.join(BASE_DIR, '.env')

def is_smtp_configured():
    """
    Check if SMTP credentials are provided in environment.
    Reloads .env dynamically to catch edits without server restart.
    """
    load_dotenv(DOTENV_PATH, override=True)
    username = os.environ.get('MAIL_USERNAME', '').strip()
    password = os.environ.get('MAIL_PASSWORD', '').strip()
    return bool(username and password)

def get_smtp_config():
    """
    Retrieve SMTP configuration from environment with sensible defaults.
    Reloads .env dynamically so credential changes take effect immediately.
    """
    load_dotenv(DOTENV_PATH, override=True)
    username = os.environ.get('MAIL_USERNAME', '').strip()
    password = os.environ.get('MAIL_PASSWORD', '').strip()
    
    # If sender is not specified or uses placeholder domain, use the authenticated Gmail username
    default_sender = os.environ.get('MAIL_DEFAULT_SENDER', '').strip()
    if username and (not default_sender or 'no-reply@saishalogistics.com' in default_sender):
        sender = f"Saisha Logistics <{username}>"
    else:
        sender = default_sender or (f"Saisha Logistics <{username}>" if username else 'Saisha Logistics <no-reply@saishalogistics.com>')

    return {
        'server': os.environ.get('MAIL_SERVER', 'smtp.gmail.com').strip(),
        'port': int(os.environ.get('MAIL_PORT', 587)),
        'username': username,
        'password': password,
        'use_tls': os.environ.get('MAIL_USE_TLS', 'True').strip().lower() in ('true', '1', 'yes'),
        'use_ssl': os.environ.get('MAIL_USE_SSL', 'False').strip().lower() in ('true', '1', 'yes'),
        'sender': sender
    }

def send_otp_email(to_email, otp_code, user_name="User"):
    """
    Sends a 6-digit OTP verification email for password reset via SMTP.
    Matches the official Saisha Logistics corporate design.
    Returns (success: bool, message: str).
    """
    config = get_smtp_config()

    # Plain text version
    text_content = f"""Hello {user_name},

We received a request to reset your password for your Saisha Logistics portal account ({to_email}).

Your 6-digit Verification Code (OTP) is:
{otp_code}

This code will expire in 10 minutes.

SECURITY WARNING:
Do not share this OTP with anyone. Saisha Logistics staff will never ask for your verification code.
If you did not request a password reset, please ignore this email. Your account remains completely secure.

Best regards,
Saisha Logistics Support Team
"""

    # Modern, branded HTML template
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset OTP - Saisha Logistics</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background-color: #f1f5f9;
            margin: 0;
            padding: 24px 10px;
            color: #1e293b;
        }}
        .email-card {{
            max-width: 520px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
        }}
        .email-header {{
            background: #0b132b;
            color: #ffffff;
            padding: 28px 24px;
            text-align: center;
        }}
        .brand-name {{
            font-size: 24px;
            font-weight: 800;
            letter-spacing: 1.5px;
            color: #ffffff;
            margin: 0;
        }}
        .brand-sub {{
            color: #c62828;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 2px;
            margin: 4px 0 0 0;
        }}
        .email-body {{
            padding: 32px 28px;
            line-height: 1.6;
        }}
        .greeting {{
            font-size: 18px;
            font-weight: 700;
            color: #0f172a;
            margin-top: 0;
            margin-bottom: 14px;
        }}
        .email-text {{
            font-size: 14px;
            color: #475569;
            margin-bottom: 20px;
        }}
        .otp-container {{
            background: #f8fafc;
            border: 2px dashed #c62828;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            margin: 24px 0;
        }}
        .otp-label {{
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: #64748b;
            margin-bottom: 8px;
        }}
        .otp-code {{
            font-size: 36px;
            font-weight: 800;
            letter-spacing: 10px;
            color: #c62828;
            font-family: 'SF Mono', Consolas, Monaco, monospace;
            display: inline-block;
        }}
        .expire-badge {{
            font-size: 12px;
            color: #c62828;
            font-weight: 600;
            margin-top: 8px;
        }}
        .warning-box {{
            background: #fff5f5;
            border-left: 3px solid #c62828;
            padding: 12px 14px;
            border-radius: 4px;
            margin: 20px 0;
            font-size: 12.5px;
            color: #7f1d1d;
            line-height: 1.5;
        }}
        .email-footer {{
            padding: 18px;
            background: #f8fafc;
            border-top: 1px solid #e2e8f0;
            text-align: center;
            font-size: 11.5px;
            color: #94a3b8;
        }}
    </style>
</head>
<body>
    <div class="email-card">
        <div class="email-header">
            <h1 class="brand-name">SAISHA LOGISTICS</h1>
            <p class="brand-sub">FLEET OWNERS &amp; TRANSPORT CONTRACTORS</p>
        </div>
        <div class="email-body">
            <h2 class="greeting">Password Reset Verification</h2>
            <p class="email-text">
                Hello <b>{user_name}</b>,<br>
                We received a request to reset your password for your Saisha Logistics account associated with <b>{to_email}</b>. Use the verification code below to complete your password reset:
            </p>
            
            <div class="otp-container">
                <div class="otp-label">Your Verification Code</div>
                <div class="otp-code">{otp_code}</div>
                <div class="expire-badge">&#9200; Valid for 10 minutes</div>
            </div>

            <div class="warning-box">
                <b>&#9888; Security Notice:</b> Never share this verification code with anyone. Saisha Logistics staff will never ask for your OTP. If you did not make this request, your account is safe and you can safely ignore this message.
            </div>
        </div>
        <div class="email-footer">
            &copy; 2026 Saisha Logistics. All rights reserved.<br>
            This is an automated system email. Please do not reply directly to this message.
        </div>
    </div>
</body>
</html>"""

    # If SMTP credentials are missing, log clearly to console in dev mode
    if not config['username'] or not config['password']:
        print("\n" + "=" * 64, flush=True)
        print("[OTP EMAIL SIMULATION - SMTP CREDENTIALS NOT CONFIGURED]", flush=True)
        print(f"To: {to_email}", flush=True)
        print(f"OTP Code: {otp_code}", flush=True)
        print("Expires: 10 minutes", flush=True)
        print("Set MAIL_USERNAME and MAIL_PASSWORD in .env for live email delivery.", flush=True)
        print("=" * 64 + "\n", flush=True)
        return False, "SMTP credentials missing in .env (MAIL_USERNAME / MAIL_PASSWORD)."

    # Build MIME message
    msg = MIMEMultipart('alternative')
    msg['Subject'] = 'Saisha Logistics - Password Reset OTP'
    msg['From'] = config['sender']
    msg['To'] = to_email

    msg.attach(MIMEText(text_content, 'plain'))
    msg.attach(MIMEText(html_content, 'html'))

    server = None
    try:
        if config['use_ssl'] or config['port'] == 465:
            server = smtplib.SMTP_SSL(config['server'], config['port'], timeout=15)
            server.ehlo()
        else:
            server = smtplib.SMTP(config['server'], config['port'], timeout=15)
            server.ehlo()
            if config['use_tls']:
                server.starttls()
                server.ehlo()

        server.login(config['username'], config['password'])
        server.send_message(msg)
        logger.info(f"Successfully sent OTP email to {to_email}")
        print(f"\n[SMTP SUCCESS]: OTP verification email sent successfully to {to_email}\n", flush=True)
        return True, "OTP email sent successfully!"
    except Exception as exc:
        err_msg = str(exc)
        logger.error(f"Failed to send OTP email to {to_email}: {err_msg}")
        print("\n" + "=" * 64, flush=True)
        print(f"[SMTP DISPATCH ERROR TO {to_email}]", flush=True)
        print(f"Server: {config['server']}:{config['port']} (TLS={config['use_tls']}, SSL={config['use_ssl']})", flush=True)
        print(f"Username: {config['username']}", flush=True)
        print(f"Error Type: {type(exc).__name__}", flush=True)
        print(f"Error Message: {err_msg}", flush=True)
        print(f"Generated OTP Code (for testing): {otp_code}", flush=True)
        print("=" * 64 + "\n", flush=True)
        return False, err_msg
    finally:
        if server:
            try:
                server.quit()
            except Exception:
                pass

def send_password_reset_email(to_email, reset_url, user_name="User"):
    """
    Legacy helper: sends a password reset link email using standard SMTP.
    Kept for backward compatibility.
    """
    config = get_smtp_config()

    if not config['username'] or not config['password']:
        return False, "SMTP is not configured (MAIL_USERNAME / MAIL_PASSWORD missing in .env)."

    text_content = f"""Hello {user_name},

We received a request to reset your password for your Saisha Logistics portal account ({to_email}).

Please click the link below to set a new password:
{reset_url}

Note: This link will expire in 1 hour.
"""

    html_content = f"""<!DOCTYPE html>
<html><body>
<p>Hello {user_name},</p>
<p>Click <a href="{reset_url}">here</a> to reset your password.</p>
</body></html>"""

    msg = MIMEMultipart('alternative')
    msg['Subject'] = 'Reset Your Password - Saisha Logistics'
    msg['From'] = config['sender']
    msg['To'] = to_email
    msg.attach(MIMEText(text_content, 'plain'))
    msg.attach(MIMEText(html_content, 'html'))

    try:
        server = smtplib.SMTP(config['server'], config['port'], timeout=12)
        if config['use_tls']:
            server.starttls()
        server.login(config['username'], config['password'])
        server.send_message(msg)
        server.quit()
        return True, "Email sent"
    except Exception as exc:
        return False, str(exc)
