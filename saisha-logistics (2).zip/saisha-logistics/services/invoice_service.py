from datetime import date
from models import db, Invoice

def get_financial_year(ref_date=None):
    """
    Returns financial year string, e.g., '26-27' for Indian FY starting April 1.
    """
    if ref_date is None:
        ref_date = date.today()
        
    year = ref_date.year
    month = ref_date.month
    
    if month >= 4:
        fy_start = year % 100
        fy_end = (year + 1) % 100
    else:
        fy_start = (year - 1) % 100
        fy_end = year % 100
        
    return f"{fy_start:02d}-{fy_end:02d}"

def get_next_invoice_number(ref_date=None, user_id=None):
    """
    Automatically increments and returns next unique invoice number:
    SL/001/26-27, SL/002/26-27, etc.
    Global across the entire company so no collision occurs between users.
    """
    fy = get_financial_year(ref_date)
    prefix = f"SL/"
    suffix = f"/{fy}"
    
    # Query all invoices that match this pattern across all users
    invoices = Invoice.query.filter(Invoice.invoice_no.like(f"{prefix}%{suffix}")).all()
    
    max_num = 0
    for inv in invoices:
        try:
            # Extract middle number: SL/037/26-27 -> 37
            parts = inv.invoice_no.split('/')
            if len(parts) == 3:
                num = int(parts[1])
                if num > max_num:
                    max_num = num
        except (ValueError, IndexError):
            continue
            
    next_num = max_num + 1
    candidate = f"SL/{next_num:03d}/{fy}"
    # Ensure generated number is strictly not taken by any existing invoice
    while Invoice.query.filter_by(invoice_no=candidate).first():
        next_num += 1
        candidate = f"SL/{next_num:03d}/{fy}"
        
    return candidate
