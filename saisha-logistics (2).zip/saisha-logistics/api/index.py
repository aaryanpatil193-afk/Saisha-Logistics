import sys
import os

# Add parent directory to path so Flask app modules can be resolved
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import app
