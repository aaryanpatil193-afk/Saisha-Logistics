from datetime import datetime, date
from models import db

class Payment(db.Model):
    __tablename__ = 'payments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True, default=1, index=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoices.id'), nullable=False, index=True)
    amount = db.Column(db.Float, nullable=False)
    payment_date = db.Column(db.Date, nullable=False, default=date.today)
    payment_mode = db.Column(db.String(50), default='Bank Transfer') # Bank Transfer, UPI, Cheque, Cash
    reference_no = db.Column(db.String(100), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('payments', lazy=True))
    invoice = db.relationship('Invoice', back_populates='payments')
    
    @property
    def formatted_date(self):
        if self.payment_date:
            return self.payment_date.strftime('%d-%m-%Y')
        if self.created_at:
            return self.created_at.strftime('%d-%m-%Y')
        return '-'

    @property
    def timestamp_str(self):
        if self.created_at:
            return self.created_at.strftime('%d-%m-%Y %H:%M')
        if self.payment_date:
            return self.payment_date.strftime('%d-%m-%Y')
        return '-'

    def to_dict(self):
        return {
            'id': self.id,
            'invoice_id': self.invoice_id,
            'invoice_no': self.invoice.invoice_no if self.invoice else '',
            'amount': self.amount,
            'payment_date': self.payment_date.strftime('%Y-%m-%d') if self.payment_date else '',
            'formatted_date': self.formatted_date,
            'timestamp_str': self.timestamp_str,
            'payment_mode': self.payment_mode or 'Bank Transfer',
            'reference_no': self.reference_no or '',
            'notes': self.notes or ''
        }

    def __repr__(self):
        return f'<Payment {self.id}: ₹{self.amount} for Invoice {self.invoice_id}>'
