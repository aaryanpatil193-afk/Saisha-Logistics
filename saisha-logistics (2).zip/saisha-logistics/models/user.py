from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from models import db

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(120), nullable=False, default='Administrator')
    email = db.Column(db.String(120), nullable=True)
    role = db.Column(db.String(30), default='admin')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Security Questions for Password Recovery
    sec_first_project = db.Column(db.String(255), nullable=True)
    sec_first_job_city = db.Column(db.String(255), nullable=True)
    sec_first_software = db.Column(db.String(255), nullable=True)
    sec_first_job_role = db.Column(db.String(255), nullable=True)

    # Legacy columns (kept for backwards compatibility)
    sec_fav_dish = db.Column(db.String(255), nullable=True)
    sec_childhood_name = db.Column(db.String(255), nullable=True)
    sec_fav_teacher = db.Column(db.String(255), nullable=True)
    sec_birthplace = db.Column(db.String(255), nullable=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def set_security_answers(self, first_project='', first_job_city='', first_software='', first_job_role='', **kwargs):
        p = first_project or kwargs.get('fav_dish', '')
        c = first_job_city or kwargs.get('childhood_name', '')
        s = first_software or kwargs.get('fav_teacher', '')
        r = first_job_role or kwargs.get('birthplace', '')

        if p and str(p).strip():
            h = generate_password_hash(str(p).strip().lower())
            self.sec_first_project = h
            self.sec_fav_dish = h
        if c and str(c).strip():
            h = generate_password_hash(str(c).strip().lower())
            self.sec_first_job_city = h
            self.sec_childhood_name = h
        if s and str(s).strip():
            h = generate_password_hash(str(s).strip().lower())
            self.sec_first_software = h
            self.sec_fav_teacher = h
        if r and str(r).strip():
            h = generate_password_hash(str(r).strip().lower())
            self.sec_first_job_role = h
            self.sec_birthplace = h

    def check_security_answer(self, question_key, provided_answer):
        if not provided_answer or not str(provided_answer).strip():
            return False

        key_mapping = {
            'first_project': ['sec_first_project', 'sec_fav_dish'],
            'first_job_city': ['sec_first_job_city', 'sec_childhood_name'],
            'first_software': ['sec_first_software', 'sec_fav_teacher'],
            'first_job_role': ['sec_first_job_role', 'sec_birthplace'],
            'fav_dish': ['sec_first_project', 'sec_fav_dish'],
            'childhood_name': ['sec_first_job_city', 'sec_childhood_name'],
            'fav_teacher': ['sec_first_software', 'sec_fav_teacher'],
            'birthplace': ['sec_first_job_role', 'sec_birthplace'],
        }

        cols = key_mapping.get(question_key, [f"sec_{question_key}"])
        stored_hash = None
        for col in cols:
            val = getattr(self, col, None)
            if val:
                stored_hash = val
                break

        if not stored_hash:
            return False
        clean_input = str(provided_answer).strip().lower()
        if stored_hash.startswith(('scrypt:', 'pbkdf2:')):
            return check_password_hash(stored_hash, clean_input)
        return stored_hash.strip().lower() == clean_input

    def get_available_security_questions(self):
        questions = []
        if self.sec_first_project or self.sec_fav_dish:
            questions.append(('first_project', 'What was the first project you worked on?'))
        if self.sec_first_job_city or self.sec_childhood_name:
            questions.append(('first_job_city', 'In which city did you complete your first job?'))
        if self.sec_first_software or self.sec_fav_teacher:
            questions.append(('first_software', 'What was the first software you learned to use?'))
        if self.sec_first_job_role or self.sec_birthplace:
            questions.append(('first_job_role', 'What was your first job role?'))
        return questions
        
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'full_name': self.full_name,
            'email': self.email,
            'role': self.role
        }

    def __repr__(self):
        return f'<User {self.username}>'
