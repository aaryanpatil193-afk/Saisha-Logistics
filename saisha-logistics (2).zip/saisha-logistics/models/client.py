from datetime import datetime
from models import db

class Client(db.Model):
    __tablename__ = 'clients'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, default=1, index=True)
    name = db.Column(db.String(150), nullable=False, index=True)
    address = db.Column(db.Text, nullable=False)
    mobile = db.Column(db.String(25), nullable=False)
    email = db.Column(db.String(120), nullable=True)
    gst_number = db.Column(db.String(20), nullable=True, index=True)
    pan_number = db.Column(db.String(15), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('clients', lazy=True))
    invoices = db.relationship('Invoice', back_populates='client', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'address': self.address,
            'mobile': self.mobile,
            'email': self.email or '',
            'gst_number': self.gst_number or '',
            'pan_number': self.pan_number or ''
        }

    def __repr__(self):
        return f'<Client {self.name}>'
