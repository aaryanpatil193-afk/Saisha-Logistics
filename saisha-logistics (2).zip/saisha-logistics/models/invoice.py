from datetime import datetime, date
from models import db

class Invoice(db.Model):
    __tablename__ = 'invoices'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, default=1, index=True)
    invoice_no = db.Column(db.String(50), nullable=False, index=True)
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'), nullable=False, index=True)

    __table_args__ = (
        db.UniqueConstraint('user_id', 'invoice_no', name='uq_user_invoice_no'),
    )
    
    # Dates
    bill_date = db.Column(db.Date, nullable=False, default=date.today)
    movement_date = db.Column(db.Date, nullable=True)
    
    # Transport Details
    transport_mode = db.Column(db.String(50), nullable=True, default='Road')
    from_location = db.Column(db.String(150), nullable=False)
    to_location = db.Column(db.String(150), nullable=False)
    vehicle_no = db.Column(db.String(50), nullable=False, index=True)
    container_no = db.Column(db.String(50), nullable=True)
    vehicle_type = db.Column(db.String(100), nullable=True)
    department = db.Column(db.String(100), nullable=True)
    weight = db.Column(db.String(50), nullable=True)
    
    # Charges Breakdown
    rate = db.Column(db.Float, default=0.0)
    advance = db.Column(db.Float, default=0.0)
    loading_charges = db.Column(db.Float, default=0.0)
    container_loading_charges = db.Column(db.Float, default=0.0) # alias for backward compatibility
    unloading_charges = db.Column(db.Float, default=0.0)
    parking_charges = db.Column(db.Float, default=0.0)
    detention_charges = db.Column(db.Float, default=0.0)
    detention_days = db.Column(db.String(50), nullable=True)
    detention_description = db.Column(db.String(100), nullable=True)
    varahi_charges = db.Column(db.Float, default=0.0)
    weight_charges = db.Column(db.Float, default=0.0)
    
    # Totals & Calculations
    total_charges = db.Column(db.Float, default=0.0) # Rate + Loading + Unloading + Parking + Detention + Varahi + Weight
    gross_total = db.Column(db.Float, default=0.0)   # Total Charges - Advance
    
    # Payment Tracking
    paid_amount = db.Column(db.Float, default=0.0)
    pending_amount = db.Column(db.Float, default=0.0)
    payment_status = db.Column(db.String(30), default='Pending', index=True) # Pending, Partially Paid, Paid
    
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('invoices', lazy=True))
    client = db.relationship('Client', back_populates='invoices')
    items = db.relationship('InvoiceItem', back_populates='invoice', cascade='all, delete-orphan')
    payments = db.relationship('Payment', back_populates='invoice', cascade='all, delete-orphan')
    stops = db.relationship('InvoiceStop', back_populates='invoice', cascade='all, delete-orphan',
                             order_by='InvoiceStop.stop_order')
    
    @property
    def total_bill_amount(self):
        """Actual total bill amount for the invoice (gross total or total charges)."""
        gross = float(self.gross_total or 0.0)
        if gross > 0:
            return round(gross, 2)
        tot = float(self.total_charges or 0.0)
        if tot > 0:
            return round(tot, 2)
        return 0.0

    @property
    def total_paid_amount(self):
        """Sum of all partial payment records dynamically linked to this invoice."""
        from models.payment import Payment
        if self.id:
            db_payments = Payment.query.filter_by(invoice_id=self.id).all()
            active_payments = [p for p in db_payments if p not in db.session.deleted]
            if active_payments:
                return round(sum(float(p.amount or 0.0) for p in active_payments), 2)
            return 0.0
        if self.payments:
            active_payments = [p for p in self.payments if p not in db.session.deleted]
            if active_payments:
                return round(sum(float(p.amount or 0.0) for p in active_payments), 2)
        return 0.0

    @property
    def pending_balance(self):
        """Real-time live remaining pending balance accurately calculated."""
        tot = self.total_bill_amount
        paid = self.total_paid_amount
        return round(max(0.0, tot - paid), 2)

    def get_payment_breakdown(self):
        """Returns chronological list of all payments with running paid total and remaining balance."""
        from models.payment import Payment
        breakdown = []
        tot = self.total_bill_amount
        running_paid = 0.0
        
        if self.id:
            db_payments = Payment.query.filter_by(invoice_id=self.id).order_by(
                Payment.payment_date.asc(), Payment.created_at.asc(), Payment.id.asc()
            ).all()
            sorted_payments = [p for p in db_payments if p not in db.session.deleted]
        else:
            active_payments = [p for p in self.payments if p not in db.session.deleted]
            sorted_payments = sorted(
                active_payments,
                key=lambda p: (
                    p.payment_date or date.min,
                    p.created_at or datetime.min,
                    p.id or 0
                )
            )
        
        for idx, p in enumerate(sorted_payments, start=1):
            amt = float(p.amount or 0.0)
            running_paid = round(running_paid + amt, 2)
            rem = round(max(0.0, tot - running_paid), 2)
            p_date = p.payment_date.strftime('%d-%m-%Y') if p.payment_date else '-'
            t_stamp = p.created_at.strftime('%d-%m-%Y %H:%M') if p.created_at else p_date
            breakdown.append({
                'installment_no': idx,
                'payment_id': p.id,
                'amount': amt,
                'payment_date': p.payment_date,
                'date_str': p_date,
                'timestamp_str': t_stamp,
                'payment_mode': p.payment_mode or 'Bank Transfer',
                'reference_no': p.reference_no or '-',
                'notes': p.notes or '',
                'running_paid': running_paid,
                'remaining_balance': rem
            })
        return breakdown

    def calculate_totals(self):
        """Backend calculation of invoice charges and dynamic multi-installment settlement balance."""
        r = float(self.rate or 0.0)
        loading = float(self.loading_charges or self.container_loading_charges or 0.0)
        unloading = float(self.unloading_charges or 0.0)
        p_charges = float(self.parking_charges or 0.0)
        d_charges = float(self.detention_charges or 0.0)
        varahi = float(self.varahi_charges or 0.0)
        w_charges = float(self.weight_charges or 0.0)
        adv = float(self.advance or 0.0)
        
        self.total_charges = round(r + loading + unloading + p_charges + d_charges + varahi + w_charges, 2)
        self.gross_total = round(self.total_charges - adv, 2)
        
        # Dynamically sum all partial payment records
        self.paid_amount = self.total_paid_amount
        total_bill = self.total_bill_amount
        self.pending_amount = round(max(0.0, total_bill - self.paid_amount), 2)
        
        # Real-time status update based on live balance
        if total_bill > 0 and self.pending_amount <= 0.0:
            self.payment_status = 'Paid'
            self.pending_amount = 0.0
        elif self.paid_amount > 0:
            self.payment_status = 'Partially Paid'
        else:
            self.payment_status = 'Pending'
            
    def to_dict(self):
        return {
            'id': self.id,
            'invoice_no': self.invoice_no,
            'client_id': self.client_id,
            'client_name': self.client.name if self.client else '',
            'client_address': self.client.address if self.client else '',
            'client_mobile': self.client.mobile if self.client else '',
            'client_gst': self.client.gst_number if self.client else '',
            'bill_date': self.bill_date.strftime('%Y-%m-%d') if self.bill_date else '',
            'movement_date': self.movement_date.strftime('%Y-%m-%d') if self.movement_date else '',
            'transport_mode': self.transport_mode or 'Road',
            'from_location': self.from_location,
            'to_location': self.to_location,
            'stops': [s.location for s in self.stops],
            'vehicle_no': self.vehicle_no,
            'container_no': self.container_no or '',
            'vehicle_type': self.vehicle_type or '',
            'department': self.department or '',
            'weight': self.weight or '',
            'rate': self.rate,
            'advance': self.advance,
            'loading_charges': self.loading_charges or self.container_loading_charges or 0.0,
            'container_loading_charges': self.container_loading_charges or self.loading_charges or 0.0,
            'unloading_charges': self.unloading_charges or 0.0,
            'parking_charges': self.parking_charges or 0.0,
            'detention_charges': self.detention_charges or 0.0,
            'detention_days': self.detention_days or '',
            'detention_description': self.detention_description or '',
            'varahi_charges': self.varahi_charges or 0.0,
            'weight_charges': self.weight_charges or 0.0,
            'total_charges': self.total_charges,
            'gross_total': self.gross_total,
            'total_bill_amount': self.total_bill_amount,
            'paid_amount': self.paid_amount,
            'total_paid_amount': self.total_paid_amount,
            'pending_amount': self.pending_amount,
            'pending_balance': self.pending_balance,
            'payment_status': self.payment_status,
            'payments': [p.to_dict() for p in self.payments]
        }

    def __repr__(self):
        return f'<Invoice {self.invoice_no}>'


class InvoiceItem(db.Model):
    __tablename__ = 'invoice_items'
    
    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoices.id'), nullable=False, index=True)
    item_date = db.Column(db.Date, nullable=True)
    particulars = db.Column(db.Text, nullable=False)
    quantity = db.Column(db.String(50), default='1')
    rate = db.Column(db.Float, default=0.0)
    advance = db.Column(db.Float, default=0.0)
    amount = db.Column(db.Float, default=0.0)
    
    invoice = db.relationship('Invoice', back_populates='items')
    
    def __repr__(self):
        return f'<InvoiceItem {self.id} for Invoice {self.invoice_id}>'


class InvoiceStop(db.Model):
    """An intermediate stop on a delivery route, between the From and To locations."""
    __tablename__ = 'invoice_stops'

    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoices.id'), nullable=False, index=True)
    stop_order = db.Column(db.Integer, nullable=False, default=0)
    location = db.Column(db.String(150), nullable=False)

    invoice = db.relationship('Invoice', back_populates='stops')

    def __repr__(self):
        return f'<InvoiceStop {self.location} for Invoice {self.invoice_id}>'
