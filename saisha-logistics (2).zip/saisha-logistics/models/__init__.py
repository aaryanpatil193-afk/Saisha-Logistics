from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

from models.user import User
from models.client import Client
from models.invoice import Invoice, InvoiceItem, InvoiceStop
from models.payment import Payment
from models.settings import AppSetting
from models.password_reset_otp import PasswordResetOTP

__all__ = ['db', 'User', 'Client', 'Invoice', 'InvoiceItem', 'InvoiceStop', 'Payment', 'AppSetting', 'PasswordResetOTP']
